package com.aaar.vinapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.aaar.vinapp.database.Topic;
import com.aaar.vinapp.database.TopicDao;
import com.aaar.vinapp.database.VinAppDatabase;

public class MainActivity extends AppCompatActivity {

    EditText editTextAddTopic;
    Button buttonSave;
    public static final String EXTRA_REPLY = "com.example.android.wordlistsql.REPLY";
    private Topic topic;
    private TopicDao topicDao;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        VinAppDatabase vinAppDatabase = VinAppDatabase.getDatabase(this);
        topicDao = vinAppDatabase.topicDao();


        editTextAddTopic = (EditText) findViewById(R.id.editTextAddTopic);
        buttonSave = (Button) findViewById(R.id.buttonSave);

        buttonSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                topic = new Topic(editTextAddTopic.getText().toString());
                topicDao.insert(topic);

            }
        });
    }
}
